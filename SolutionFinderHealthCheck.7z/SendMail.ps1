﻿$body = ""
$counterfordate = 0
$currdate = Get-Content "C:\SolutionFinderHealthCheck\date.txt"
foreach ($line1 in Get-Content "C:\SolutionFinderHealthCheck\FinalHTML.txt") {
    $body = $body + $line1
      

}

$count = 1
$currentdate = Get-Date
$mode =  Get-Content "C:\SolutionFinderHealthCheck\mode.txt"
if($mode -eq "auto"){
if ($currentdate.Hour -eq 08 -and $currentdate.Minute -eq 00) {
    foreach ($contact in Get-Content "C:\SolutionFinderHealthCheck\StakeHolderMailReceipents.txt") {

        if ($count -eq 1) {
            $fromarray = $contact
        }
        elseif ($count -eq 2) {
            $toarray = $contact
        }
        elseif ($count -eq 3) {
            $ccarray = $contact
        }
        else {
            $bccarray = $contact
        }
        $count = $count + 1

    }
}
else {
    foreach ($contact in Get-Content "C:\SolutionFinderHealthCheck\MailReceipents.txt") {

        if ($count -eq 1) {
            $fromarray = $contact
        }
        elseif ($count -eq 2) {
            $toarray = $contact
        }
        elseif ($count -eq 3) {
            $ccarray = $contact
        }
        else {
            $bccarray = $contact
        }
        $count = $count + 1

    }


}
}
else{
    $whom = Read-Host -Prompt 'Enter whom to send the HC status Enter Normal for regular folks or Stake for important stakeholders'
    if ($whom -eq "Stake") {
    foreach ($contact in Get-Content "C:\SolutionFinderHealthCheck\StakeHolderMailReceipents.txt") {

        if ($count -eq 1) {
            $fromarray = $contact
        }
        elseif ($count -eq 2) {
            $toarray = $contact
        }
        elseif ($count -eq 3) {
            $ccarray = $contact
        }
        else {
            $bccarray = $contact
        }
        $count = $count + 1

    }
}
else {
    foreach ($contact in Get-Content "C:\SolutionFinderHealthCheck\MailReceipents.txt") {

        if ($count -eq 1) {
            $fromarray = $contact
        }
        elseif ($count -eq 2) {
            $toarray = $contact
        }
        elseif ($count -eq 3) {
            $ccarray = $contact
        }
        else {
            $bccarray = $contact
        }
        $count = $count + 1

    }


}

}

$from = $fromarray.Split(":")[1].Split(";")
$to = $toarray.Split(":")[1].Split(";")
$cc = $ccarray.Split(":")[1].Split(";")
$bcc = $bccarray.Split(":")[1].Split(";")

$remark = "NULL"

if(Test-Path -Path "C:\SolutionFinderHealthCheck\DelibrateList.txt"){
$remark = "<p><b>Remark: Below services are delibrately Stopped</b>"

foreach ($line2 in Get-Content "C:\SolutionFinderHealthCheck\DelibrateList.txt") {
 
    $remark = $remark + "<br>" + $line2 
     
     }

}

$salutation = "<p class=MsoNormal style='ver
    tical-align:baseline'>
    <b>
                <span style='font-size:10.0pt;color:#002469;mso-fareast-language:EN-GB'>Regards,
                   
                </span><br>
            </b>
            <b>
                <span style='font-size:10.0pt;color:#002469;mso-fareast-language:EN-GB'>Product Finder AM Support &#8211; CPB Tech Production Services | CPB Services
                   
                </span>
            </b><br>
        
            <b>
                <span style='font-size:10.0pt;color:#002469;mso-fareast-language:EN-GB'>Royal Bank of Scotland Group
                   
                </span>
            </b><br>
        
            <b>
                <span style='font-size:10.0pt;color:#002469;mso-fareast-language:EN-GB'>Email: FM-042247@rbos.co.uk
                   
                </span>
            </b>
 </p>"

$domain = Get-Content "C:\SolutionFinderHealthCheck\temp5.txt"
$racf = Get-Content "C:\SolutionFinderHealthCheck\temp3.txt"
$getcontentemail = Get-Content "C:\SolutionFinderHealthCheck\temp4.txt" | ConvertTo-SecureString
$emailpassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($getcontentemail))


    
Import-module "C:\Program Files\Microsoft\Exchange\Web Services\2.2\Microsoft.Exchange.WebServices.dll"
$version = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2010_SP2
$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($version)
$username = "$domain\$racf"
$password = $emailpassword
$service.Credentials = New-Object Microsoft.Exchange.WebServices.Data.WebCredentials -ArgumentList $username, $password
$url = "https://euhubwebmail.rbsres01.net/ews/Exchange.asmx"
$service.Url = $url
$message = New-Object Microsoft.Exchange.WebServices.Data.EmailMessage -ArgumentList $service

$message.From = $from[0].ToString()
foreach ($toelement in $to) {
    $toelement
    $message.ToRecipients.Add($toelement)
}
    
foreach ($ccelement in $cc) {
    $ccelement
    $message.CCRecipients.Add($ccelement)
}

    
foreach ($bccelement in $bcc) {
    $bccelement
    if ($bccelement -ne '') {
        $message.BCCRecipients.Add($bccelement)
    }
}
$message.Subject = "Product Finder - MVP Health Check Report (Date: " + $currdate + ")"
if($remark -eq "NULL"){
$message.Body = $body +  $salutation}

else{
$message.Body = $body +  $remark + "</p>" + $salutation}
$message.SendAndSaveCopy()

Remove-Item -Path "C:\SolutionFinderHealthCheck\FinalHTML.txt"
Remove-Item -Path "C:\SolutionFinderHealthCheck\OverAllRed.txt"
New-Item -Path "C:\SolutionFinderHealthCheck\OverAllRed.txt" -ItemType file
if(Test-Path -Path "C:\SolutionFinderHealthCheck\DelibrateList.txt")
{
Remove-Item -Path "C:\SolutionFinderHealthCheck\DelibrateList.txt"    
}