﻿########################################################################################################################################################################
#
# Script Name   : MainScript.ps1
# Author        : Ravi Joshi
# Function      : Product Finder application monitoring script
# Requester     : Product Finder Application  Management
# Support Team  :
# Project       : Product Finder
# Date          : 05-11-2018
# Description   : This script performs following checks
#                    1) Retrives the apps on Prod Space in and checks for the status of the same
#                    2) Checks all the related parts of application using Rest API calls for both NatWest and RBS.
#                    3) Checks certificate details for NatWest , RBS and S3 Bucket.
#                    4) Send the mail via Exchange WebService 2.2
#   This script runs on Windows machine as it is written in Powershell.                  
#   To make the script run it has to be injected in a bat file and the bat file has to be run manually or automatically by setting in Task Scheduler.
########################################################################################################################################################################


#This function checks URL for Product Finder Journey
function UrlCheck {

    param (  $urltotest,
        $natproxyurl
    )
    
    #This will test each unit of journey through REST API.
    Invoke-WebRequest -Uri $urltotest -Proxy $natproxyurl -ProxyUseDefaultCredentials > "C:\SolutionFinderHealthCheck\statuscode.txt";
    if ((Get-Content "C:\SolutionFinderHealthCheck\statuscode.txt") -eq $Null) {


        return "<td id=td1red>Not Passed</td>" 
    }
    else {

     
        return  "<td id=td1green>Passed</td>"

    }
}

#This function checks for availability of apps.

function appscheck {

    param (  $appsdata,
        $brand, $ext, $naturltest
    )
   
    $natwestarray = [System.Collections.ArrayList]@()
    $control = 0
    $control1 = 0
    $natindex = 0
    $statusflag = 1
    $delibratecount = 0
    "<tr><th id=th3>Services</th><th id=th1>" + $brand + "</th><th id=th2> Status </th><th id=th2> URL </th></tr>" >> "C:\SolutionFinderHealthCheck\HTML.txt"
    
    for ($appindex = 4; $appindex -lt $appsdata.Length; $appindex++) {

  
        $arrayofdata = @()
        $arrayofdata = $appsdata[$appindex].Split("")
        $index1 = 0
        $index2 = 0
        $j = 1
    
        $tokensarray = ("NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA")
        foreach ($character in $arrayofdata) {

              
            if ($character -ne "") {
                $tokensarray[$index2] = $character
                $index2++
            }
            $index1++    
        
        } 

        

        $k = 0

        Do {
        
        
            if ($k -eq 0) {
           
                $matchinstring = $tokensarray[0] -match $ext
              
                if ($matchinstring -eq "True") {
           
                    $arrayid = $natwestarray.Add($tokensarray[$k])
           
                
                }

            }

            if ($k -eq 1) {

              
                if ($tokensarray[0] -match $ext) {
                    $arrayid = $natwestarray.Add($tokensarray[$k])
           
            
                }

            }
                
            

            
            $k++
                  
        } while ($k -le $tokensarray.Length)
        
          
      
         
         
    }

    
    $filepath = "C:\SolutionFinderHealthCheck\" + $brand + ".txt"
    $natwestarray | Out-File $filepath
    $control = 0
    $control1 = 0
    $natindex = 0
    foreach ($line in Get-Content $filepath) {
        if ($line -eq "started" -or $line -eq "stopped") {
        
            if ($line -eq "started") {
                 
                "`n" + "<td id=td1white><b>Up</b></td><td id=td1green>" + "Green" + "</td>" + $naturltest[$natindex]  >> "C:\SolutionFinderHealthCheck\HTML.txt"
                $natindex = $natindex + 1
                "</tr>" >> "C:\SolutionFinderHealthCheck\HTML.txt"
            }
            else {
                "`n" + "<td id=td1white><b>Down</b></td><td id=td1red>" + "Red" + "</td>" + $naturltest[$natindex] >> "C:\SolutionFinderHealthCheck\HTML.txt"
                $natindex = $natindex + 1
              
            } 

            
            
        
        }
        else {
            if ($control -eq 0) {
                "<tr>" >> "C:\SolutionFinderHealthCheck\HTML.txt"

            }
            else {
                "<tr>" >> "C:\SolutionFinderHealthCheck\HTML.txt"
            }
            if ($line -match 'client') {"`n" + "<td id=td1center><b>" + "UI SERVICE" + "</b></td>" >> "C:\SolutionFinderHealthCheck\HTML.txt" }
            elseif ($line -match 'decision') { "<td id=td1center><b>" + "µ DECISION SERVICE" + "</b></td>" >> "C:\SolutionFinderHealthCheck\HTML.txt" }
            elseif ($line -match 'pdf') {"`n" + "<td id=td1center><b>" + "µ PDF CREATOR SERVICE" + "</b></td>" >> "C:\SolutionFinderHealthCheck\HTML.txt" }
            elseif ($line -match 'pmp') {"`n" + "<td id=td1center><b>" + "µ PRODUCT MANAGEMENT SERVICE" + "</b></td>" >> "C:\SolutionFinderHealthCheck\HTML.txt" }
            elseif ($line -match 'pricing') {"`n" + "<td id=td1center><b>" + "µ PRICING SERVICE" + "</b></td>" >> "C:\SolutionFinderHealthCheck\HTML.txt"  }
        
            $control++
        
            $delibratestatus = Select-String -Path "C:\SolutionFinderHealthCheck\DelibrateStopped.txt" $line
            if($delibratestatus.Matches.Success){ $delibratecount = $delibratecount + 1
             if ($line -match 'client') { "UI SERVICE on "+$brand >> "C:\SolutionFinderHealthCheck\DelibrateList.txt" }
            elseif ($line -match 'decision') {"µ DECISION SERVICE on "+$brand>> "C:\SolutionFinderHealthCheck\DelibrateList.txt" }
            elseif ($line -match 'pdf') {"µ PDF CREATOR SERVICE on "+$brand >> "C:\SolutionFinderHealthCheck\DelibrateList.txt" }
            elseif ($line -match 'pmp') {"µ PRODUCT MANAGEMENT SERVICE on "+$brand >> "C:\SolutionFinderHealthCheck\DelibrateList.txt" }
            elseif ($line -match 'pricing') {"µ PRICING SERVICE on "+$brand >> "C:\SolutionFinderHealthCheck\DelibrateList.txt"  }
                
            }
          
        }
        if ($line -eq "stopped") { if($delibratecount -eq 0){ $statusflag = 0; $stoppedcounter = $stoppedcounter + 1; continue}}
    
    
    }

    if ($statusflag -eq 1) {
        "Green" > "C:\SolutionFinderHealthCheck\OverAllGreen.txt"
    }
    else {
        "Red" > "C:\SolutionFinderHealthCheck\OverAllRed.txt"
    }

    Remove-Item $filepath

}

$currdate = Get-Date
$timezone = "BST"
if ($currdate.IsDaylightSavingTime()) {
    $timezone = "BST"
}
else {
    $timezone = "GMT"
}

#This inserts a date into a file for further user.
$currdate.GetDateTimeFormats()[70].ToString() + " " + $timezone  > "C:\SolutionFinderHealthCheck\date.txt"

#Create a initial static HTMLdetails.

'<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">' > "C:\SolutionFinderHealthCheck\HTML.txt"
"<style> 
h1 { 
color: blue; 
font-family: verdana; 
align-content: center;
font-size: 
12px;
} 
h2 
{ 
font-family: verdana;
font-size: 11.0pt;
}
table {
    border-collapse: collapse;
     width: 55%;
}

table, th, td {
    border: 1px solid black;
    font-family: Calibri Light , sans-serif;
    font-size: 11.0pt;
    background-color: #990099;
    color: white;
    font-style: bold;  
   
}

#th1{
  background-color: #0070C0;
  border: 1px solid black;
  color: white ;
  font-family: Calibri Light , sans-serif;
  font-size: 11.0pt;
  text-align: center;      
            

}

#th2{
  background-color: #990099;
  border: 1px solid black;
  color: white;
  font-family: Calibri Light , sans-serif;
  font-size: 11.0pt;
        
            

}


#th3{
  background-color:  #0070C0;
  border: 1px solid black;
  color: white;
  font-family: Calibri Light , sans-serif;
  font-size: 11.0pt;
   text-align: left;       
            

}

#th2green{
            background-color: #92D050;
            color: black;

        }
        #th2amber{
            background-color: rgb(248, 167, 16);
            color: black;
            
        }
        #th2red{
            background-color: rgb(243, 10, 10);
            color: black;
            
        }

        #td1green{
            background-color: #92D050;
            text-align: center;
            color: black;

        }
        #td1amber{
            background-color: rgb(248, 167, 16);
            text-align: center;
            
        }
        #td1red{
            background-color: rgb(243, 10, 10);
            text-align: center;
            color: black;
            
        }

        #td1white{
            background-color: white;
            text-align: center;
            color: black;
            
        }

        #td1cert{
            
            text-align: center;
            
            
        }
        #td1center{text-align: left;}

#p1{ font-family:
verdana;

font-size: 
12px;

}
p{ align-content:
center;
font-size: 
12px;
font-family: verdana;

} 

pre{
font-size: 
15px;
font-family: verdana;
}


</style>" >> "C:\SolutionFinderHealthCheck\HTML.txt"
"<p> Hi All,
</p>

<p> Please find the health check status for Product Finder (MVP).</p>" >> "C:\SolutionFinderHealthCheck\HTML.txt"


"<table border=10 bordercolor=black> 
                        <tr><th colspan=4 id=th1> Product Finder - MVP  - Prod Health Check Report ( Date:  " + $currdate.GetDateTimeFormats()[70].ToString() + " " + $timezone + ")</th></tr>" >> "C:\SolutionFinderHealthCheck\HTML.txt"

"<tr><th id=th3 colspan=2> Overall Status </th>"  >> "C:\SolutionFinderHealthCheck\HTML.txt"

#This checks if all the rquired files are available or not.
if ((Test-Path "C:\SolutionFinderHealthCheck\temp1.txt") -and (Test-Path "C:\SolutionFinderHealthCheck\temp2.txt") -and (Test-Path "C:\SolutionFinderHealthCheck\temp3.txt") -and (Test-Path "C:\SolutionFinderHealthCheck\temp4.txt") -and (Test-Path "C:\SolutionFinderHealthCheck\temp5.txt")) {
    $username = Get-Content "C:\SolutionFinderHealthCheck\temp1.txt"
    $getcontent = Get-Content "C:\SolutionFinderHealthCheck\temp2.txt" | ConvertTo-SecureString
    $password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($getcontent))
    $racf = Get-Content "C:\SolutionFinderHealthCheck\temp3.txt"
    $getcontentemail = Get-Content "C:\SolutionFinderHealthCheck\temp4.txt" | ConvertTo-SecureString
    $emailpassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($getcontentemail))
    $objExcel = New-Object -ComObject Excel.Application
    $objExcel.Visible = $false
    $WorkBook = $objExcel.Workbooks.Open("C:\SolutionFinderHealthCheck\Parameters.xlsx")
    $sheets = $WorkBook.sheets | Select-Object -Property Name
    foreach ($sheet in $sheets.Name) {
        $worksheet = $WorkBook.sheets.item($sheet)
        $env = $worksheet.Range("B1").Text
        $ext = $worksheet.Range("B11").Text
        $NatMailUrl = $worksheet.Range("B2").Text
        $NatDecisionUrl = $worksheet.Range("B3").Text
        $NatPDFUrl = $worksheet.Range("B4").Text
        $NatPMPUrl = $worksheet.Range("B5").Text
        $NatPricingUrl = $worksheet.Range("B6").Text
        $NatCertUrl = $worksheet.Range("B7").Text
        $NatS3Url = $worksheet.Range("B8").Text
        $MailUrl = $worksheet.Range("B9").Text
        #$NatPDFHeader = $worksheet.Range("B10").Text
        $DefaultUrl = $worksheet.Range("B10").Text
        $statusflag = 1
        $stoppedcounter = 0
        $naturltest = [System.Collections.ArrayList]@()
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $natproxyurl = ([System.Net.WebRequest]::GetSystemWebproxy()).GetProxy($DefaultUrl)
        $returnfromUrlCheck = UrlCheck -urltotest $NatMailUrl -natproxyurl $natproxyurl
        $naturltest.Add($returnfromUrlCheck)
        $returnfromUrlCheck = UrlCheck -urltotest $NatDecisionUrl -natproxyurl $natproxyurl
        $naturltest.Add($returnfromUrlCheck)
        if ($currdate.Hour -eq 08) {
            $returnfromUrlCheck = UrlCheck -urltotest $NatPDFUrl -natproxyurl $natproxyurl
            $naturltest.Add($returnfromUrlCheck)
        }
        else {
            $naturltest.Add("<td id=td1green>PDF Creation Check will happen at 08:00 only</td>")
        }
        $returnfromUrlCheck = UrlCheck -urltotest $NatPMPUrl -natproxyurl $natproxyurl
        $naturltest.Add($returnfromUrlCheck)
        $returnfromUrlCheck = UrlCheck -urltotest $NatPricingUrl  -natproxyurl $natproxyurl
        $naturltest.Add($returnfromUrlCheck)
        cf login -a api.sys.mvp01.pace-mvp.com -u $username -p $password -o solution-finder -s $env
        $appsdata = cf apps
        appscheck -appsdata $appsdata -brand $sheet -ext $ext -naturltest $naturltest

    }
}


else {

    Read-Host -Prompt 'Enter your PCF userid' | Out-File "C:\SolutionFinderHealthCheck\temp1.txt"
    Read-Host  -AsSecureString 'Enter your password of PCF - Make sure you enter the correct password' | ConvertFrom-SecureString | Out-File "C:\SolutionFinderHealthCheck\temp2.txt"
    Read-Host -Prompt 'Enter your Email Domain' | Out-File "C:\SolutionFinderHealthCheck\temp5.txt"
    Read-Host -Prompt 'Enter your email RACFid' | Out-File "C:\SolutionFinderHealthCheck\temp3.txt"
    Read-Host  -AsSecureString 'Enter your email password - Make sure you enter the correct password' | ConvertFrom-SecureString | Out-File "C:\SolutionFinderHealthCheck\temp4.txt"

}

$WorkBook.Close()
$objExcel.Quit()
"</table>" >> "C:\SolutionFinderHealthCheck\HTML.txt"




"<table> <tr>
<th id=th1 colspan=5><b> Certificate Status <b></th>
</tr>
<tr>
<th id=th1><b> Common Name <b></th>
<th id=th1><b> Issue Date <b></th>
<th id=th1><b> End Date <b></th>
<th id=th1><b> Days Remaining <b></th>
<th id=th2><b> Status <b></th>
</tr>" >> "C:\SolutionFinderHealthCheck\HTML.txt"


$filecontent = Get-Content "C:\SolutionFinderHealthCheck\OverAllRed.txt"

if ( $filecontent -eq "Red") {

              
    "<th id=th2Red colspan=2> Red </th></tr>" > "C:\SolutionFinderHealthCheck\overall.txt"

}
else {
    "<th id=th2green colspan=2> Green </th></tr>" > "C:\SolutionFinderHealthCheck\overall.txt"
            
}
