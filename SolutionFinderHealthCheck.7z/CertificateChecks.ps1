﻿#Script to test certificate URLs


#This function checks the details of certificate for each URL
function CertificateChecks {
    param(
        $certurltotest, 
        $natproxyurl, 
        $curdate
            
    )
   
    $newurltotest = $certurltotest 
    Invoke-WebRequest -Uri $newurltotest -Proxy $natproxyurl -ProxyUseDefaultCredentials
    $webRequest = [Net.WebRequest]::Create($newurltotest)

    try { $webRequest.GetResponse() } catch {}
    $cert = $webRequest.ServicePoint.Certificate

    
    $certdetails = $cert.Subject.Split(",")[0].Split("=")
    $startdate = $cert.GetEffectiveDateString()
    $enddate = $cert.GetExpirationDateString()
    $datediff = NEW-TIMESPAN –Start $curdate –End $enddate
    $datediff.Days
    $datearray = $startdate.Split("/")
    $startdate = $datearray[1] + "/" + $datearray[0] + "/" + $datearray[2] 
    $datearray = $enddate.Split("/")
    $enddate = $datearray[1] + "/" + $datearray[0] + "/" + $datearray[2] 
  
     
    
    "<tr><td id=td1cert><b>" + $certdetails[1] + "</b></td>" + "<td id=td1cert>" + $startdate + "</td>" + "<td id=td1cert>" + $enddate + "</td>" + "<td id=td1cert>" + $datediff.Days + "</td>" >> "C:\SolutionFinderHealthCheck\HTML.txt"

    if ($datediff.Days -ge 90) {

        "<td id=td1green>" + "Green" + "</td></tr>" >> "C:\SolutionFinderHealthCheck\HTML.txt"

    }
    elseif ($datediff.Days -gt 30) {

        "<td id=td1amber>" + "Start Working on Certificate" + "</td></tr>" >> "C:\SolutionFinderHealthCheck\HTML.txt"

    }
    else {
        "<td id=td1red>" + "Red" + "</td></tr>" >> "C:\SolutionFinderHealthCheck\HTML.txt"
    }
     
}


#Create a Excel Object for reading
$objExcel = New-Object -ComObject Excel.Application
$objExcel.Visible = $false
$WorkBook = $objExcel.Workbooks.Open("C:\SolutionFinderHealthCheck\Parameters.xlsx")
$sheets = $WorkBook.sheets | Select-Object -Property Name
$currentdate = Get-Date

#Loop the excel for each sheet for getting the details like App names, App Status
foreach ($sheet in $sheets.Name) {

    
    $worksheet = $WorkBook.sheets.item($sheet)
    $certurl1 = $worksheet.Range("B7").Text
    $certurl2 = $worksheet.Range("B8").Text
    $DefaultUrl = $worksheet.Range("B10").Text
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $natproxyurl = ([System.Net.WebRequest]::GetSystemWebproxy()).GetProxy($DefaultUrl)
    CertificateChecks -certurltotest $certurl1 -natproxyurl $natproxyurl -curdate $currentdate
    CertificateChecks -certurltotest $certurl2 -natproxyurl $natproxyurl -curdate $currentdate
}
$WorkBook.Close()
$objExcel.Quit()
"</table>" >> "C:\SolutionFinderHealthCheck\HTML.txt"

$countinglines = 0


#Insert the details of HTML.txt to Final HTML.
foreach ($line1 in Get-Content "C:\SolutionFinderHealthCheck\HTML.txt") {
    if ($countinglines -eq 141) {
        $line1 >> "C:\SolutionFinderHealthCheck\FinalHTML.txt";
          
        $content = Get-Content "C:\SolutionFinderHealthCheck\overall.txt"
        $content
        $content >> "C:\SolutionFinderHealthCheck\FinalHTML.txt";

    }
    else {
        $line1 >> "C:\SolutionFinderHealthCheck\FinalHTML.txt";
            
    }
    $countinglines = $countinglines + 1

}

# Mail sending Script is invoked here

Invoke-Expression "C:\SolutionFinderHealthCheck\SendMail.ps1"


